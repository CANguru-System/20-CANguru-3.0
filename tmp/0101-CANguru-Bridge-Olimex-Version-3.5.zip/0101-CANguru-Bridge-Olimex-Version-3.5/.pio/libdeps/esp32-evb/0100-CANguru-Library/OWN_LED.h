#ifndef OWN_LED
#define OWN_LED

void LED_begin(uint8_t LED_);
void LED_on();
void LED_off();

#endif